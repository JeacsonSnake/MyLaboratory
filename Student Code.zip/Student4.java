Public class Student4{
	public static viod main(String args){
		System.out.print("Even");
	}
}